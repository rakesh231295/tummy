<footer style="background-image: url(assets/img/tummy/footer.jpg);background-color: #f5f8fd;">
   <div class="container">
      <div class="row">
         <div class="col-xl-4 col-lg-6">
            <div class="logo-white">
<!--               <a href="index.html"><img alt="logo-white" src="assets/img/logo-white.png"></a>-->
               <a href="index.php"><h2 style="color:#fff;">Hello Tummy</h2></a>
               <p>All Days Open - 24/7
               </p>
              
            </div>
         </div>
         <div class="col-xl-2 col-lg-3 col-md-6">
            <div class="link-about">
               <h3>About</h3>
               <ul>
                  <li><i class="fa-solid fa-angle-right"></i><a href="#">Information</a></li>
                  <li><i class="fa-solid fa-angle-right"></i><a href="#">Special Dish</a></li>
                  <li><i class="fa-solid fa-angle-right"></i><a href="#">Reservation</a></li>
                  <li><i class="fa-solid fa-angle-right"></i><a href="#">Contact</a></li>
               </ul>
            </div>
         </div>
         <div class="col-xl-2 col-lg-3 col-md-6">
            <div class="link-about">
               <h3>menu</h3>
               <ul>
                  <li><i class="fa-solid fa-angle-right"></i><a href="#">Steaks</a></li>
                  <li><i class="fa-solid fa-angle-right"></i><a href="#">Burgers</a></li>
                  <li><i class="fa-solid fa-angle-right"></i><a href="#">Coctails</a></li>
                  <li><i class="fa-solid fa-angle-right"></i><a href="#">Bar B Q</a></li>
                  <li><i class="fa-solid fa-angle-right"></i><a href="#">Desserts</a></li>
               </ul>
            </div>
         </div>
         <div class="col-xl-4 col-lg-6">
            <div class="link-about">
               <h3>Newsletter</h3>
               <p>Get recent news and updates.</p>
               <form class="footer-form">
                  <input type="text" name="Enter Your Email Address" placeholder="Enter Your Email Address...">
                  <button class="button">Subscribe</button>
               </form>
            </div>
         </div>
      </div>
      <div class="footer-bootem">
         <h6><span>© 2024 hello Tummy</span> | All Rights Reserved.</h6>
         <div class="header-social-media">
            <a href="#">Facebook</a>
            <a href="#">Twitter</a>
            <a href="#">Instagram</a>
            <a href="#">Youtube</a>   
         </div>
      </div>
   </div>
</footer>
<!-- progress -->
<div id="progress">
      <span id="progress-value"><i class="fa-solid fa-arrow-up"></i></span>
</div>

<!-- Bootstrap Js -->
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<!-- fancybox -->
<script src="assets/js/jquery.fancybox.min.js"></script>
<script src="assets/js/custom.js"></script>

<!-- Form Script -->
<script src="assets/js/contact.js"></script>
<script type="text/javascript" src="assets/js/sweetalert.min.js"></script>
</body>