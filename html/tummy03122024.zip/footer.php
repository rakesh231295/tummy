<footer class="mt-4" style="background-image: url(assets/img/tummy/footer.jpg);background-color: #f5f8fd;padding-top:0;">
   <div class="container">
      <div class="row">
         
       
        
      </div>
      <div class="footer-bootem" style="margin-top: 0;">
         <h6><span>© 2024 Hello Tummy</span> | All Rights Reserved.</h6>
         <div class="header-social-media">
            <a href="https://thaliwalaa.com/">Thaliwalaa</a>
            <a href="https://burnerstory.com/">Burner Story</a>
            <a href="#">Homely Aroma</a>
          
         </div>
      </div>
   </div>
</footer>
<!-- progress -->
<div id="progress">
      <span id="progress-value"><i class="fa-solid fa-arrow-up"></i></span>
</div>

<!-- Bootstrap Js -->
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<!-- fancybox -->
<script src="assets/js/jquery.fancybox.min.js"></script>
<script src="assets/js/custom.js"></script>

<!-- Form Script -->
<script src="assets/js/contact.js"></script>
<script type="text/javascript" src="assets/js/sweetalert.min.js"></script>
</body>